package com.atividade.AvaliacaoPW;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvaliacaoPwApplication {

	public static void main(String[] args) {
		SpringApplication.run(AvaliacaoPwApplication.class, args);
	}

}
