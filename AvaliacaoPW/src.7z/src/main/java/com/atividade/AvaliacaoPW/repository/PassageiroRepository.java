package com.atividade.AvaliacaoPW.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.atividade.AvaliacaoPW.models.Passageiro;

public interface PassageiroRepository extends JpaRepository<Passageiro, Long>{

}
